## Foodie PWA
I created a simple PWA that show a list of restaurants, add to favourite and add review.

npm run start-dev to run on development mode
npm run build to build the app